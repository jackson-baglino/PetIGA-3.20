#ifndef ENV_CONFIG_H
#define ENV_CONFIG_H

#include "user_context.h"

// ========================= Function Declarations =========================
PetscErrorCode GetEnvironment(AppCtx *user);
void InitializeUserContext(AppCtx *user);

#endif // ENV_CONFIG_H